package com.zoho.attendance.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.zoho.attendance.entity.DepartmentDetail;
import com.zoho.attendance.service.DepartmentService;

@Controller
@RequestMapping(path = "/departmentdetail")
public class DepartmentController {
		
		@Autowired
		DepartmentService departmentservice;
	
		@PostMapping(path="/adddepartment")
		@ResponseBody
		public String adddepartment(@RequestBody DepartmentDetail departmentdetail) {	
			
			return departmentservice.adddepartment(departmentdetail);
		}
		
		@GetMapping(path = "/findalldepartment")
		@ResponseBody
		public List<DepartmentDetail> findalldepartment() {
			 return departmentservice.findalldepartment();
		}
		
}
