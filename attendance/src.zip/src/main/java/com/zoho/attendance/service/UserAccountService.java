
package com.zoho.attendance.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.zoho.attendance.entity.UserAccount;
import com.zoho.attendance.repository.UserAccountRepository;

@Service("userAccountService")
public class UserAccountService {

    
    private UserAccountRepository userAccountRepository;
	
	@Autowired
    public UserAccountService(UserAccountRepository userAccountRepository) {
        this.userAccountRepository = userAccountRepository;   
    }

   
    public String addUser(UserAccount useraccount) {
    	String ret = null;
    	UserAccount userAccountList = userAccountRepository.findByEmployeeId(useraccount.getEmployeeId());
    	if(userAccountList==null) {
    		userAccountRepository.save(useraccount);
    		ret = "User account has been added, user name = " + useraccount.getEmployeeId();
    	}
        return ret;

    }
    
    public List<UserAccount> findAllUser() {
        List<UserAccount> userAccountList = (List<UserAccount>) userAccountRepository.findAll();
        if (userAccountList != null) {
            return userAccountList;
        }
        return null;
    }

    
    public UserAccount findByEmployeeId(String employeeId) {
        UserAccount userAccountList = userAccountRepository.findByEmployeeId(employeeId);
        if (userAccountList != null) {
           return userAccountList;
        }
        return null;
    }

   
    public String updateUser(UserAccount useraccount) {

        UserAccount userAccountList = userAccountRepository.findByEmployeeId(useraccount.getEmployeeId());

        if (userAccountList != null) {            
        	userAccountList.setEmployeeId(useraccount.getEmployeeId());
        	userAccountList.setPassword(useraccount.getPassword());
            userAccountRepository.save(userAccountList);
            return ("User data update successfully.");            
        }
        return "No record found";
    }
    
}