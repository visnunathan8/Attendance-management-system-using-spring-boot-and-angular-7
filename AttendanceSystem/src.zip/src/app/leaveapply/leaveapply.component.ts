import { Component, OnInit } from '@angular/core';
import { LeavedetailService, leavedetail } from '../service/leavedetail.service';

@Component({
  selector: 'app-leaveapply',
  templateUrl: './leaveapply.component.html',
  styleUrls: ['./leaveapply.component.css']
})
export class LeaveapplyComponent implements OnInit {
  public aleave:leavedetail
  public empleave:leavedetail
  empid=''
  reason=''
  date=''
  constructor(private leave:LeavedetailService) { }

  ngOnInit() {
  }
  submit(){
    this.aleave = new leavedetail(this.empid,this.reason,"no",this.date);
    this.leave.createEmployee(this.aleave)
    .subscribe( (data) => {
      console.log(JSON.stringify(data))
      
      this.empleave = data
    }
    );
    alert("Leave has been requested.Please wait for the approval");
    this.empid=''
  this.reason=''
  this.date=''
  }
}
