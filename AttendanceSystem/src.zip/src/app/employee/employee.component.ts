import { Component, OnInit, Input } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { EmployeedetailService, employeedetail } from '../service/employeedetail.service';

@Component({
  selector: 'app-employee',
  templateUrl:'employee.component.html',
  styles: ['employee.component.css']
})
export class EmployeeComponent implements OnInit {
  public employee:employeedetail;
  name="asd"
  constructor(private router: Router,private route:ActivatedRoute,private employeeservice : EmployeedetailService,
  ) {
    console.log("leaveapply");
    this.def();
   }

  ngOnInit() {
  }
check(){
  console.log("leaveapply");
  this.router.navigate(['./leaveapply'],{relativeTo:this.route});
}
def(){
  this.employeeservice.getEmployee("emp1")
  .subscribe( (data) => {
    
    console.log(JSON.stringify(data)) 
    this.employee = data
}


  );
}
}