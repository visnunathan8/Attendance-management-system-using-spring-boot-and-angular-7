import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { AdminComponent } from './admin/admin.component';
import { DepartmentComponent } from './department/department.component';
import { EmployeeComponent } from './employee/employee.component';
import { AuthGuard } from './auth.guard';
import { LeaveapplyComponent } from './leaveapply/leaveapply.component';
import {AttendanceempComponent} from './attendanceemp/attendanceemp.component'
export const routes: Routes = [
    { path: '', component: LoginComponent },
    { path: 'leaveapply', component: LeaveapplyComponent },
    { path: 'attenemp', component: AttendanceempComponent },
    { 
      path: 'login', 
      component: LoginComponent,
      canActivate:[AuthGuard]
   },
    {
      path: 'admin',
      component: AdminComponent,
      canActivate:[AuthGuard]
     /* children:[
        { path: 'createemployee', component: LoginComponent },
        { path: '', component: LoginComponent },
        { path: 'overallattendance', component: LoginComponent },
      ]*/
     
    },
    {
      path: 'dept',
      component: DepartmentComponent,
      canActivate:[AuthGuard]
      /*children:[
        { path: 'attendance', component: LoginComponent },
        { path: 'leaveaprroval', component: LoginComponent },
        { path: 'overallattendance', component: LoginComponent },
      ]*/
    },
    { 
      path: 'emp',
      component: EmployeeComponent,
      canActivate:[AuthGuard],
      children:[
        { path: 'attendance', component: LoginComponent },
        { path: 'salary', component: LoginComponent },
        { path: 'overallattendance', component: LoginComponent },
        
      ]
    },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
