import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../service/authentication.service';
import { useraccount, UseraccountService } from '../service/useraccount.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styles: []
})
export class LoginComponent implements OnInit {

  employeeId = ''
  password = ''
  invalidLogin = false
  user: useraccount;
  public employee:useraccount;
  constructor(private userService: UseraccountService,private router: Router,
    private loginservice: AuthenticationService) { }
    //messageemp = this.employeeId;
  ngOnInit() {
  }
  checkLogin() {
    
    this.user = new useraccount(this.employeeId,this.password,"admin");
    console.log("ASD"+this.employeeId+" "+this.password);
    this.userService.getEmployee(this.employeeId)
    .subscribe( (data) => {
      //console.log(JSON.stringify(data))
      
      this.employee = data
     // console.log(this.employee.employeeId)
     if(this.employee!=null){
          if(this.employee.employeeId=="admin"){
            if(this.employee.password==this.password){
              this.router.navigate(['admin'])
              this.userService.setLoggedIn(true);
              return true;

            }else{
              this.router.navigate(['login'])
              alert("ENTER THE CORRECT USERNAME AND PASSWORD :(");
              return false;
            }
          }else if(this.employee.employeeId=="dept"){
            if(this.employee.password==this.password){
              this.router.navigate(['dept'])
              this.userService.setLoggedIn(true);
              return true;
            }else{
              this.router.navigate(['login'])
              alert("ENTER THE CORRECT USERNAME AND PASSWORD :(");
              return false;
            }
          }else{
            if(this.employee.password==this.password){
              console.log("PLZZ");
              this.router.navigate(['emp'])
              console.log("PLZZ11");
              this.userService.setLoggedIn(true);
              return true;
            }else{
              this.router.navigate(['login'])
              alert("ENTER THE CORRECT USERNAME AND PASSWORD :(");
              return false;
            }
          }
          alert("ENTER THE CORRECT USERNAME AND PASSWORD :(");
          this.router.navigate(['login']);
          return false;
     }else{
      this.employeeId=""
      this.password=""
      alert("ENTER THE CORRECT USERNAME AND PASSWORD :(");
     }
    }
    
    );
    // if (this.loginservice.authenticate(this.username, this.password)
    // ) {
    //   this.router.navigate(['./addemployee'])
    //   this.invalidLogin = false
    // } else
    //   this.invalidLogin = true
  }

}
