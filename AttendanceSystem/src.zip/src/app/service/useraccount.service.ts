import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

export class useraccount{
  constructor(
    public employeeId:string,
    public password:string,
    public type:string
  ){}
}
@Injectable({
  providedIn: 'root'
})
export class UseraccountService {
  loggedInStatus = false
  constructor(
   private http:HttpClient
  ) { }

setLoggedIn(value:boolean){
  this.loggedInStatus = value
}   

get isLoggedIn(){
  return this.loggedInStatus
}
  getEmployee(empid: String) {
    console.log("from user account service");
    return this.http.get<useraccount>('http://localhost:8081/userAccount/findbyempid?employeeId='+empid);
  }
  createEmployee(employee: useraccount) {
       return this.http.post<useraccount>('http://localhost:8081/userAccount/adduseraccount/', employee);
   }
  
  // createEmployee(employee: Employee) {
  //   return this.http.post<string>('http://localhost:8081/userAccount/adduseraccount/', employee);
  // }

  updateEmployee(employee: useraccount) {
    return this.http.post<string>('http://localhost:8081/userAccount/updateuser/${id}', employee);
  }

  getEmployeesList() {
    return this.http.get<useraccount[]>('http://localhost:8081/userAccount/findalluseraccounts/');
  }
}
