import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
export class attendace{
  constructor( 
    public id:number,
		public employeeId:string,
		public month:string,
		public date:number,
		public departmentId:string,
		public available:boolean,
		public checkin:string,
		public checkout:string
){}
}
@Injectable({
  providedIn: 'root'
})
export class AttendancedetailService {

  constructor(private http:HttpClient) { }

  getattendance(atten:String) {
    console.log("FREE");
    return this.http.get<attendace[]>("http://localhost:8081/attendancedetail/findbyempidatten?employeeid="+ atten);
}
}
