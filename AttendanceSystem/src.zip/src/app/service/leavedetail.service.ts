import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';

export class leavedetail{
  constructor(
    public employeeId:string,
    public leavereason:string,
    public date:string,
    public leavetype:string

  ){}
}

@Injectable({
  providedIn: 'root'
})
export class LeavedetailService {

  constructor(private http:HttpClient) { }

  createEmployee(leave: leavedetail) {
    console.log("FREE");
    return this.http.post<leavedetail>('http://localhost:8081/leavedetail/adduserleave/', leave);
}
}
