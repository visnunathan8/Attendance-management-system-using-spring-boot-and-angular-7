import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

export class employeedetail{
    constructor(
        public employeeId:string,
        public dob:Number,
        public gender:string,
        public bloodGroup:string,
        public phno:LongRange,
        public address:string,
        public department:string,
        public mailId:string,
        public firstName:string,
        public lastName:string,
        public dateOfJoining:Number,
        public salary:Number
    ){}
}
@Injectable({
  providedIn: 'root'
})
export class EmployeedetailService {

  constructor(private http:HttpClient) { }

getEmployee(empid: String) {
  console.log("from employee account service"+empid);
  return this.http.get<employeedetail>('http://localhost:8081/employeedetail/findbyempidemployee?employeeid='+empid);
}
}
