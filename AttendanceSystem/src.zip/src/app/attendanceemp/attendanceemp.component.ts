import { Component, OnInit } from '@angular/core';
import {attendace, AttendancedetailService} from '../service/attendancedetail.service'
@Component({
  selector: 'app-attendanceemp',
  templateUrl: './attendanceemp.component.html',
  styleUrls: ['./attendanceemp.component.css']
})
export class AttendanceempComponent implements OnInit {
public atten:attendace
public at:attendace[]
  public empid=''
  public month=''
  public year=''
  
  constructor(private attendance:AttendancedetailService) { }

  ngOnInit() {
  }
  submit(){
   
    this.attendance.getattendance(this.empid)
    .subscribe( (data) => {
      console.log(JSON.stringify(data))
      
      this.at = data as attendace[];
      
    }
    );
     this.empid=''
  this.month=''
  this.year=''
  }
}
